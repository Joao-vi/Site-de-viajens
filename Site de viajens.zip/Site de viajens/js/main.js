$(document).ready(function () {
  $nav = $(".nav");
  $toglleCollapse = $(".toggle-collapse");
  /** CLICK EVENT ON TOGGLE MENU  */

  $toglleCollapse.click(function () {
    $nav.toggleClass("collapse");
  });

  // OWL CAROUSEL FOR BLOG
  $(".owl-carousel").owlCarousel({
    loop: true,
    autoplay: true,
    autoplayTimeout: 3000,
    dots: false,
    nav: true,
    navText: [
      $(".owl-navigation .owl-nav-prev"),
      $(".owl-navigation .owl-nav-next"),
    ],
  });
});
